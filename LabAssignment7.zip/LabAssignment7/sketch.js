function setup() {
  createCanvas(400, 400);
  frameRate(3);
  angleMode(DEGREES);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  background(24, 35, 51);  
  noFill();
  strokeWeight(10);
  stroke(188, 204, 227, 1);
  //snowflakes
  for(let i=0; i<20; ++i) {
    push();
    scale(random(0.5, 1.5));
    rotate(random(0, 360));
    snowFlake(random(0, 400), random(0, 400));
    pop();
  }
  push();
  //window
  noStroke();
  fill(10, 12, 15, 1);
  rect(0, 0, 25, 400);
  rect(0, 0, 400, 25);
  rect(0, 375, 400, 25);
  rect(375, 0, 25, 400);
  rect(187, 0, 25, 400);
  rect(0, 187, 400, 25);
  pop();
}

function snowFlake(x, y) {
  translate(x, y);  
  ellipse(0, 0, 50, 50)
  line(-40, -40, 40, 40);
  line(-40, 40, 40, -40);
  line(0, -50, 0, -30);
  line(-50, 0, -30, 0);
  line(0, 50, 0, 30);
  line(50, 0, 30, 0);
}