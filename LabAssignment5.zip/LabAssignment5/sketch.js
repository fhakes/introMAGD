function setup() {
  cx = 600; //minimum width is 380
  cy = 400; //minimum height is 270
  createCanvas(cx, cy);
  colorMode(RGB, 255, 255, 255, 1);
  color1 = [188, 214, 214]; //mid-blue
  color2 = [79, 194, 194]; //sat-blue
  color3 = [194, 79, 79]; //inverted 2
  color4 = [232, 250, 250]; //light-blue
  color5 = [36, 59, 59]; //dark-blue
  screen = color5;
  detail = color5;
  frameRate(30);
  noStroke();
}

function draw() {
  background(color1);
  //screen
  fill(screen);
  rect(25, 25, (cx-50), (cy-150));
  //power button
  fill(color3);
  ellipse(65, cy-65, 75, 75)
  fill(color4);
  ellipse(65, cy-65, 40, 40);
  fill(color3);
  ellipse(65, cy-65, 30, 30);
  
  //detail button
  fill(color2);
  rect(125, cy-100, 125, 75);
  
  //x button
  fill(color4);
  rect(cx-100, cy-100, 75, 75);
  stroke(color5);
  strokeWeight(5);
  line(cx-90, cy-90, cx-35, cy-35);
  line(cx-90, cy-35, cx-35, cy-90);
  noStroke();
  
  //detail squares / tool bar thing
  fill(color5);
  rect(25, cy-150, (cx-50), 25);
  rect(40, cy-190, 25, 25);
  rect(40, cy-230, 25, 25);
  rect(80, cy-190, 25, 25);
  rect(cx-65, 40, 25, 25);
  
  //center detail
  fill(detail)
  rect(cx/2-50, 50, 100, cy-225)
  
  //inverts color of center detail if x is pressed
  //center detail must be visible, otherwise x button does nothing
  if(keyIsPressed) {
    if(key == 'x') {
      if((mouseX > cx-100) && (mouseX < cx-25) && (mouseY > cy-100) && (mouseY < cy-25)) {
        if(detail==color2) {
          detail=color3;
        } else if(detail==color3) {
          detail=color2;
        }
      }
    }
  }
  
}

function mousePressed() {
  d = dist(mouseX, mouseY, 65, cy-65);
  if(d<75/2) {
    if(screen==color5) {
      screen = color4;
      detail=color4;
    } else {
      screen = color5;
      detail=color5;
    }
  }
  
  if((mouseX>125)&&(mouseX<250)&&(mouseY>cy-100)&&(mouseY<cy-25)) {
    if(screen==color4) { //checks if screen is "on"
      if(detail==color4) { //swaps color between sat / light
        detail=color2;
      } else {
        detail=color4;
      }
    } else {
      detail = color5;
    }
  }
}