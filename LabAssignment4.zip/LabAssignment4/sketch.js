function setup() {
  x = 400;
  y = 400;
  createCanvas(x, y);
  fr = 10;
  numX = 0;
  numY = 0;
  noStroke();
  frameRate(fr);
}
value = 0;
function draw() {
  background(value);
  fill(abs(value-255));
  for(let i = 0; i<=x; i=i+50) {
    for(let j = 0; j<=y; j=j+50) {
      circle(i, j, 30);
    }
  }
  fill(value);
  
  if (keyIsPressed) {
    circle(numX, numY, 31);
    numX=numX-50;
    if(numX<0) {
      numX = x;
      numY=numY-50;
    }
    if(numY<0) {
      numY = y;
    }
  } else {
    circle(numX, numY, 31);
    numX=numX+50;
    if(numX>x) {
      numX = 0;
      numY=numY+50;
    }
    if(numY>y) {
      numY = 0;
    }
  }
}

  
function mousePressed() {
  if(value == 0) {
    value = 255;
  }
  else {
    value = 0;
  }
  
}
